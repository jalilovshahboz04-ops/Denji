import sqlite3
import json
from datetime import datetime

DB_NAME = "bot_database.db"

def get_db_connection():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Foydalanuvchilar jadvali
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            first_name TEXT,
            mood TEXT,
            joined_at TEXT
        )
    """)
    
    # Suhbat tarixi jadvali
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            role TEXT,
            content TEXT,
            timestamp TEXT
        )
    """)
    
    # Eslatmalar jadvali
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS reminders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            chat_id INTEGER,
            user_id INTEGER,
            text TEXT,
            fire_at TEXT
        )
    """)
    
    conn.commit()
    conn.close()

def upsert_user(user_id, username, first_name):
    conn = get_db_connection()
    cursor = conn.cursor()
    now = datetime.utcnow().isoformat()
    cursor.execute("""
        INSERT INTO users (user_id, username, first_name, joined_at)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(user_id) DO UPDATE SET
            username = excluded.username,
            first_name = excluded.first_name
    """, (user_id, username, first_name, now))
    conn.commit()
    conn.close()

def save_message(user_id, role, content):
    conn = get_db_connection()
    cursor = conn.cursor()
    now = datetime.utcnow().isoformat()
    cursor.execute("""
        INSERT INTO history (user_id, role, content, timestamp)
        VALUES (?, ?, ?, ?)
    """, (user_id, role, content, now))
    conn.commit()
    conn.close()

def load_history(user_id, limit=20):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT role, content FROM history
        WHERE user_id = ?
        ORDER BY id DESC LIMIT ?
    """, (user_id, limit))
    rows = cursor.fetchall()
    conn.close()
    
    # Tarixni to'g'ri tartibda (eski xabardan yangisiga) qaytarish
    history = [{"role": row["role"], "content": row["content"]} for row in rows]
    history.reverse()
    return history

def clear_history(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM history WHERE user_id = ?", (user_id,))
    conn.commit()
    conn.close()

def set_mood(user_id, mood):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET mood = ? WHERE user_id = ?", (mood, user_id))
    conn.commit()
    conn.close()

def get_mood(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT mood FROM users WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()
    conn.close()
    return row["mood"] if row else None

def clear_mood(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET mood = NULL WHERE user_id = ?", (user_id,))
    conn.commit()
    conn.close()

def save_reminder(chat_id, user_id, text, fire_at):
    conn = get_db_connection()
    cursor = conn.cursor()
    fire_at_str = fire_at.isoformat()
    cursor.execute("""
        INSERT INTO reminders (chat_id, user_id, text, fire_at)
        VALUES (?, ?, ?, ?)
    """, (chat_id, user_id, text, fire_at_str))
    reminder_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return reminder_id

def get_pending_reminders():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, chat_id, user_id, text, fire_at FROM reminders")
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]

def delete_reminder(reminder_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM reminders WHERE id = ?", (reminder_id,))
    conn.commit()
    conn.close()

def get_user_stats(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) as cnt FROM history WHERE user_id = ? AND role = 'user'", (user_id,))
    row = cursor.fetchone()
    conn.close()
    return {"msg_count": row["cnt"] if row else 0}

def get_global_stats():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) as cnt FROM users")
    u_row = cursor.fetchone()
    cursor.execute("SELECT COUNT(*) as cnt FROM history WHERE role = 'user'")
    m_row = cursor.fetchone()
    conn.close()
    return {
        "total_users": u_row["cnt"] if u_row else 0,
        "total_messages": m_row["cnt"] if m_row else 0
    }
import asyncio
import os
import random
import re
import requests
from google import genai
from google.genai import types as genai_types
from gtts import gTTS
from bs4 import BeautifulSoup
from openai import OpenAI
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import ApplicationBuilder, MessageHandler, CommandHandler, ContextTypes, filters
from datetime import datetime, timedelta
from database import (
    init_db, upsert_user, save_message, load_history, clear_history,
    get_user_stats, get_global_stats, set_mood, get_mood, clear_mood,
    save_reminder, get_pending_reminders, delete_reminder,
)

BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN")
if not BOT_TOKEN:
    raise RuntimeError("TELEGRAM_BOT_TOKEN environment variable is not set")

GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")
if not GEMINI_API_KEY:
    raise RuntimeError("GEMINI_API_KEY environment variable is not set")

OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
openai_client = OpenAI(api_key=OPENAI_API_KEY) if OPENAI_API_KEY else None

gemini_client = genai.Client(api_key=GEMINI_API_KEY)

SYSTEM_PROMPT = """
Sen haqiqiy insondek AI do'stsan.
Isming Nova.
Suhbatni eslab qolasan.
Emotsiya bilan javob berasan.
Ba'zan kulgili, ba'zan jiddiy bo'lasan.
Foydalanuvchi qo'llab-quvvatlaysan.
"""


MOOD_HINTS = {
    "xafa":      "\nFoydalanuvchi o'zini xafa his qilyapti. Har doim iliq, yupatuvchi va mehribon bo'l.",
    "xursand":   "\nFoydalanuvchi xursand kayfiyatda. Energetik, quvnoq va birga quvonuvchi bo'l.",
    "charchagan": "\nFoydalanuvchi charchagan. Sokin, qisqa va engillashtiruvchi javob ber.",
    "stress":    "\nFoydalanuvchi stressda. Bosiq, tinchlantiruvchi va yechim taklif qiluvchi bo'l.",
    "yolg'iz":   "\nFoydalanuvchi yolg'iz his qilyapti. Doimiy hamroh va do'stona bo'l.",
    "g'azabli":  "\nFoydalanuvchi g'azabda. Sakin, tushunuvchi va muloyim bo'l.",
    "baxtiyor":  "\nFoydalanuvchi juda baxtli. Birga nishonla va ijobiy energiya ber.",
    "bezovta":   "\nFoydalanuvchi bezovtalangan. Tinchlantiruvchi va ishonch beruvchi javob ber.",
}

MOOD_EMOJIS = {
    "xafa": "😔", "xursand": "😊", "charchagan": "😴",
    "stress": "😰", "yolg'iz": "🥺", "g'azabli": "😤",
    "baxtiyor": "🥳", "bezovta": "😟",
}

EMOTION_HINTS = {
    "xafa":     "Foydalanuvchi xafa, iliq va mehribon javob ber.",
    "yig'la":   "Foydalanuvchi yig'layapti, yupatuvchi javob ber.",
    "yolg'iz":  "Foydalanuvchi yolg'iz his qilyapti, do'stona bo'l.",
    "qo'rqa":   "Foydalanuvchi qo'rqyapti, tinchlantiruvchi javob ber.",
    "charch":   "Foydalanuvchi charchagan, engillashtiruvchi javob ber.",
    "xursand":  "Foydalanuvchi xursand, uning kayfiyatini qo'llab-quvvat.",
    "baxtli":   "Foydalanuvchi baxtli, birga quvon.",
    "g'azab":   "Foydalanuvchi g'azablangan, sakin va tushunuvchi bo'l.",
    "stress":   "Foydalanuvchi stressda, bosiq va yordam beruvchi javob ber.",
}


def detect_emotion(text: str) -> str:
    lower = text.lower()
    for keyword, hint in EMOTION_HINTS.items():
        if keyword in lower:
            return hint
    return ""


GEMINI_MODELS = ["gemini-2.0-flash", "gemini-2.0-flash-lite", "gemini-2.5-flash"]


def get_ai_reply(user_id: int, text: str) -> str:
    extra = detect_emotion(text)
    saved_mood = get_mood(user_id)
    mood_hint = MOOD_HINTS.get(saved_mood, "") if saved_mood else ""
    system = SYSTEM_PROMPT.strip() + mood_hint + (f"\n{extra}" if extra else "")

    history = load_history(user_id, limit=20)
    gemini_history = [
        genai_types.Content(
            role="user" if msg["role"] == "user" else "model",
            parts=[genai_types.Part(text=msg["content"])],
        )
        for msg in history
    ]

    save_message(user_id, "user", text)

    last_error = None
    for model_name in GEMINI_MODELS:
        try:
            chat = gemini_client.chats.create(
                model=model_name,
                config=genai_types.GenerateContentConfig(system_instruction=system),
                history=gemini_history,
            )
            response = chat.send_message(text)
            answer = response.text or "..."
            save_message(user_id, "assistant", answer)
            return answer
        except Exception as e:
            err = str(e)
            if "429" in err or "RESOURCE_EXHAUSTED" in err:
                last_error = e
                continue
            raise

    raise last_error


async def handle_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.message.from_user
    upsert_user(user.id, user.username, user.first_name)
    name = user.first_name or "do'st"
    markup = ReplyKeyboardMarkup(
        [[KeyboardButton("Help"), KeyboardButton("About")]],
        resize_keyboard=True,
    )
    await update.message.reply_text(
        f"👋 Salom, {name}! Men AI-powered Telegram botman.\n\n"
        "Nima qila olaman:\n"
        "  /ask <savol> — AI'dan savol so'rash\n"
        "  /imagine <tavsif> — AI rasm yaratish\n"
        "  /summarize <matn|URL> — matn yoki sahifani qisqartirish\n"
        "  /translate <til> <matn> — istalgan tilga tarjima\n"
        "  /voice <matn> — matnni ovozga aylantirish\n"
        "  /remind <daqiqa> <matn> — eslatma o'rnatish\n"
        "  /mood <kayfiyat> — kayfiyat o'rnatish\n"
        "  /clear — suhbat tarixini tozalash\n"
        "  /stats — faollik statistikasi\n"
        "  /weather <shahar> — ob-havo ma'lumoti\n"
        "  /echo <matn> — matnni takrorlash\n"
        "  /flip — tanga tashlash\n"
        "  /dice — zar o'ynash\n"
        "  /help — barcha buyruqlar\n\n"
        "💬 Yoki shunchaki yozing — AI javob beradi!",
        reply_markup=markup,
    )


async def handle_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🤖 *Buyruqlar ro'yxati*\n\n"
        "/ask <savol> — AI'dan savol so'rash\n"
        "/imagine <tavsif> — DALL\\-E 3 bilan rasm yaratish\n"
        "/summarize <matn|URL> — matn yoki veb\\-sahifani qisqartirish\n"
        "/translate <til> <matn> — istalgan tilga tarjima\n"
        "/voice <matn> — matnni ovozga aylantirish\n"
        "/remind <daqiqa> <matn> — eslatma o'rnatish\n"
        "/mood <kayfiyat> — kayfiyat o'rnatish\n"
        "/clear — suhbat tarixini tozalash\n"
        "/stats — faollik statistikasi\n"
        "/weather <shahar> — ob\\-havo ma'lumoti\n"
        "/echo <matn> — matnni takrorlash\n"
        "/flip — tanga tashlash\n"
        "/dice — zar o'ynash \\(1–6\\)\n"
        "/about — bot haqida\n"
        "/help — ushbu yordam xabari\n\n"
        "💬 Yoki xabar yuboring — AI javob beradi!",
        parse_mode="MarkdownV2",
    )


async def handle_about(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "ℹ️ *Bot haqida*\n\n"
        "Python, python\\-telegram\\-bot va Groq LLaMA3 yordamida yaratilgan\\.\n"
        "Replit'da ishlaydi\\.\n\n"
        "AI har bir suhbatda so'nggi 20 ta xabarni eslab qoladi\\.",
        parse_mode="MarkdownV2",
    )


async def handle_ask(update: Update, context: ContextTypes.DEFAULT_TYPE):
    question = update.message.text[len("/ask"):].strip()
    if not question:
        await update.message.reply_text("Ishlatish: /ask <savolingiz>\nMisol: /ask Frantsiya poytaxti qaysi?")
        return

    await context.bot.send_chat_action(update.effective_chat.id, "typing")
    try:
        reply = get_ai_reply(update.message.from_user.id, question)
        await update.message.reply_text(reply)
    except Exception as e:
        print(e)
        await update.message.reply_text(f"Xato: {e}")


async def handle_clear(update: Update, context: ContextTypes.DEFAULT_TYPE):
    clear_history(update.message.from_user.id)
    await update.message.reply_text("🗑 Suhbat tarixi tozalandi! Yangi boshlaymiz.")


async def handle_echo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text[len("/echo"):].strip()
    if text:
        await update.message.reply_text(text)
    else:
        await update.message.reply_text("Ishlatish: /echo <matn>")


async def handle_flip(update: Update, context: ContextTypes.DEFAULT_TYPE):
    result = random.choice(["Tura 🪙", "Panja 🪙"])
    await update.message.reply_text(f"Tanga natijasi: *{result}*", parse_mode="Markdown")


async def handle_dice(update: Update, context: ContextTypes.DEFAULT_TYPE):
    result = random.randint(1, 6)
    faces = {1: "⚀", 2: "⚁", 3: "⚂", 4: "⚃", 5: "⚄", 6: "⚅"}
    await update.message.reply_text(f"Zar: {faces[result]} *{result}*", parse_mode="Markdown")


async def handle_weather(update: Update, context: ContextTypes.DEFAULT_TYPE):
    city = update.message.text[len("/weather"):].strip()
    if not city:
        await update.message.reply_text("Ishlatish: /weather <shahar>\nMisol: /weather Toshkent")
        return

    await context.bot.send_chat_action(update.effective_chat.id, "typing")
    try:
        url = f"https://wttr.in/{requests.utils.quote(city)}?format=j1"
        resp = requests.get(url, timeout=10)
        if resp.status_code != 200:
            await update.message.reply_text(f"'{city}' shahri uchun ob-havo topilmadi. Shahar nomini tekshiring.")
            return

        data = resp.json()
        current = data["current_condition"][0]
        area = data["nearest_area"][0]

        area_name = area["areaName"][0]["value"]
        country = area["country"][0]["value"]
        temp_c = current["temp_C"]
        temp_f = current["temp_F"]
        feels_c = current["FeelsLikeC"]
        feels_f = current["FeelsLikeF"]
        humidity = current["humidity"]
        wind_kmph = current["windspeedKmph"]
        description = current["weatherDesc"][0]["value"]
        visibility = current["visibility"]

        weather_icons = {
            "Sunny": "☀️", "Clear": "🌙", "Partly cloudy": "⛅", "Cloudy": "☁️",
            "Overcast": "☁️", "Mist": "🌫️", "Fog": "🌫️", "Rain": "🌧️",
            "Drizzle": "🌦️", "Snow": "❄️", "Blizzard": "🌨️", "Thunder": "⛈️",
        }
        icon = next((v for k, v in weather_icons.items() if k.lower() in description.lower()), "🌡️")

        await update.message.reply_text(
            f"{icon} *{area_name}, {country} ob-havosi*\n\n"
            f"🌡 Harorat: *{temp_c}°C / {temp_f}°F*\n"
            f"🤔 His qilinadi: {feels_c}°C / {feels_f}°F\n"
            f"💧 Namlik: {humidity}%\n"
            f"💨 Shamol: {wind_kmph} km/h\n"
            f"👁 Ko'rinish: {visibility} km\n"
            f"📋 Holat: {description}",
            parse_mode="Markdown",
        )
    except requests.exceptions.Timeout:
        await update.message.reply_text("⏱ Ob-havo xizmati javob bermadi. Qayta urinib ko'ring.")
    except Exception as e:
        print(e)
        await update.message.reply_text(f"Xato: {e}")


async def handle_imagine(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not openai_client:
        await update.message.reply_text("⚠️ OPENAI_API_KEY o'rnatilmagan. Rasm yaratish ishlamaydi.")
        return

    prompt = update.message.text[len("/imagine"):].strip()
    if not prompt:
        await update.message.reply_text("Ishlatish: /imagine <tavsif>\nMisol: /imagine oyda astronavt mushuk, raqamli san'at")
        return

    await context.bot.send_chat_action(update.effective_chat.id, "upload_photo")
    generating_msg = await update.message.reply_text("🎨 Rasm yaratilmoqda...")
    try:
        response = openai_client.images.generate(
            model="dall-e-3",
            prompt=prompt,
            size="1024x1024",
            quality="standard",
            n=1,
        )
        image_url = response.data[0].url
        revised_prompt = response.data[0].revised_prompt
        image_data = requests.get(image_url, timeout=30).content

        await generating_msg.delete()
        caption = f"🎨 _{revised_prompt[:800]}_" if revised_prompt else f"🎨 _{prompt[:800]}_"
        await update.message.reply_photo(image_data, caption=caption, parse_mode="Markdown")
    except Exception as e:
        print(e)
        await generating_msg.delete()
        await update.message.reply_text(f"Xato: {e}")


async def handle_summarize(update: Update, context: ContextTypes.DEFAULT_TYPE):
    input_text = update.message.text[len("/summarize"):].strip()
    if not input_text:
        await update.message.reply_text(
            "Ishlatish:\n"
            "  /summarize <matn> — matnni qisqartirish\n"
            "  /summarize <URL> — veb-sahifani qisqartirish\n\n"
            "Misol: /summarize https://uz.wikipedia.org/wiki/O'zbekiston"
        )
        return

    await context.bot.send_chat_action(update.effective_chat.id, "typing")
    status_msg = await update.message.reply_text("📝 Tahlil qilinmoqda...")

    url_pattern = re.compile(r"https?://[^\s]+")
    url_match = url_pattern.match(input_text)

    content_to_summarize = input_text
    source_label = "📝 *Matn qisqartmasi*"

    if url_match:
        url = url_match.group(0)
        source_label = f"🔗 *Havola qisqartmasi*\n_{url}_"
        try:
            headers = {"User-Agent": "Mozilla/5.0 (compatible; TelegramBot/1.0)"}
            resp = requests.get(url, timeout=15, headers=headers)
            resp.raise_for_status()

            soup = BeautifulSoup(resp.text, "html.parser")

            for tag in soup(["script", "style", "nav", "footer", "header", "aside"]):
                tag.decompose()

            paragraphs = soup.find_all("p")
            text = " ".join(p.get_text(separator=" ", strip=True) for p in paragraphs)

            if not text.strip():
                text = soup.get_text(separator=" ", strip=True)

            content_to_summarize = text[:6000]

            if not content_to_summarize.strip():
                await status_msg.delete()
                await update.message.reply_text("⚠️ Bu sahifadan matn olib bo'lmadi. Boshqa URL yoki to'g'ridan-to'g'ri matn yuboring.")
                return

        except requests.exceptions.Timeout:
            await status_msg.delete()
            await update.message.reply_text("⏱ Sahifa javob bermadi. Keyinroq urinib ko'ring.")
            return
        except Exception as e:
            print(e)
            await status_msg.delete()
            await update.message.reply_text(f"Xato: {e}")
            return

    try:
        summary = None
        for model_name in GEMINI_MODELS:
            try:
                result = gemini_client.models.generate_content(
                    model=model_name,
                    contents=f"Quyidagi matnni qisqartir:\n\n{content_to_summarize}",
                    config=genai_types.GenerateContentConfig(
                        system_instruction=(
                            "Sen matnni qisqartiruvchi AI yordamchisan. "
                            "Berilgan matnni 3-5 asosiy fikrga qisqartir. "
                            "Har bir fikrni yangi qatorda '•' bilan boshlash. "
                            "Faqat o'zbek tilida javob ber."
                        ),
                        max_output_tokens=512,
                    ),
                )
                summary = result.text or "Qisqartma olib bo'lmadi."
                break
            except Exception as e:
                if "429" in str(e) or "RESOURCE_EXHAUSTED" in str(e):
                    continue
                raise
        if summary is None:
            raise Exception("Barcha Gemini modellari kvotasi tugagan. Keyinroq urinib ko'ring.")
        await status_msg.delete()
        await update.message.reply_text(
            f"{source_label}\n\n{summary}",
            parse_mode="Markdown",
        )
    except Exception as e:
        print(e)
        await status_msg.delete()
        await update.message.reply_text(f"Xato: {e}")


def _schedule_reminder(bot, reminder_id: int, chat_id: int, text: str, seconds: float):
    async def send_reminder():
        await asyncio.sleep(seconds)
        try:
            await bot.send_message(
                chat_id=chat_id,
                text=f"⏰ *Eslatma!*\n\n{text}",
                parse_mode="Markdown",
            )
        finally:
            delete_reminder(reminder_id)

    asyncio.create_task(send_reminder())


async def restore_reminders(bot):
    now = datetime.utcnow()
    pending = get_pending_reminders()
    restored = 0
    for r in pending:
        fire_at = datetime.fromisoformat(r["fire_at"])
        delay = (fire_at - now).total_seconds()
        if delay <= 0:
            delete_reminder(r["id"])
            continue
        _schedule_reminder(bot, r["id"], r["chat_id"], r["text"], delay)
        restored += 1
    if restored:
        print(f"[remind] {restored} eslatma qayta tiklandi.")


async def handle_remind(update: Update, context: ContextTypes.DEFAULT_TYPE):
    args = update.message.text[len("/remind"):].strip()
    if not args or " " not in args:
        await update.message.reply_text(
            "Ishlatish: /remind <daqiqa> <eslatma>\n\n"
            "Misol:\n"
            "  /remind 5 Suv ich\n"
            "  /remind 30 Mashg'ulot vaqti\n"
            "  /remind 60 Ovqat yeyish"
        )
        return

    parts = args.split(" ", 1)
    try:
        minutes = float(parts[0])
        if minutes <= 0 or minutes > 1440:
            await update.message.reply_text("⏱ Daqiqa 1 dan 1440 gacha bo'lishi kerak (maksimum 24 soat).")
            return
    except ValueError:
        await update.message.reply_text("⚠️ Birinchi qiymat raqam bo'lishi kerak.\nMisol: /remind 10 Choy ich")
        return

    reminder_text = parts[1].strip()
    chat_id = update.effective_chat.id
    user_id = update.message.from_user.id
    seconds = minutes * 60
    fire_at = datetime.utcnow() + timedelta(seconds=seconds)

    reminder_id = save_reminder(chat_id, user_id, reminder_text, fire_at)
    _schedule_reminder(context.bot, reminder_id, chat_id, reminder_text, seconds)

    label = f"{int(minutes)} daqiqa" if minutes == int(minutes) else f"{minutes} daqiqa"
    await update.message.reply_text(
        f"✅ Eslatma saqlandi!\n\n"
        f"⏰ *{label}* dan so'ng xabar yuboraman:\n"
        f"_{reminder_text}_",
        parse_mode="Markdown",
    )


async def handle_voice(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text[len("/voice"):].strip()
    if not text:
        await update.message.reply_text(
            "Ishlatish: /voice <matn>\n\n"
            "Misol: /voice Salom, qalaysiz?"
        )
        return

    await context.bot.send_chat_action(update.effective_chat.id, "record_voice")
    file = "voice.mp3"
    try:
        tts = gTTS(text, lang="uz" if is_uzbek(text) else "en")
        tts.save(file)
        await update.message.reply_voice(voice=open(file, "rb"))
    except Exception as e:
        print(e)
        await update.message.reply_text(f"Xato: {e}")
    finally:
        if os.path.exists(file):
            os.remove(file)


def is_uzbek(text: str) -> bool:
    uzbek_chars = set("oʻgʼqhOʻGʻQH")
    uzbek_words = {"salom", "qanday", "men", "sen", "bu", "va", "bilan", "uchun", "ham"}
    lower = text.lower()
    has_chars = any(c in uzbek_chars for c in text)
    has_words = any(w in lower.split() for w in uzbek_words)
    return has_chars or has_words


async def handle_translate(update: Update, context: ContextTypes.DEFAULT_TYPE):
    args = update.message.text[len("/translate"):].strip()
    if not args or " " not in args:
        await update.message.reply_text(
            "Ishlatish: /translate <til> <matn>\n\n"
            "Misol:\n"
            "  /translate ingliz Salom, qalaysiz?\n"
            "  /translate russian Hello, how are you?\n"
            "  /translate french Artificial intelligence is amazing"
        )
        return

    language, text = args.split(" ", 1)
    text = text.strip()
    if not text:
        await update.message.reply_text("Iltimos, tarjima qilinadigan matnni kiriting.")
        return

    await context.bot.send